from __future__ import annotations

from pathlib import Path

import pandas as pd

from a_stock_selector.data_provider import SampleDataProvider, save_dataset
from a_stock_selector.db import connect, init_db, table_count
from a_stock_selector.config import StrategyConfig
from a_stock_selector.strategy import _build_trade_plan, _detect_keypoint, run_strategy, score_industries


def test_sample_strategy_run_writes_required_outputs(tmp_path: Path) -> None:
    db_path = tmp_path / "selector.sqlite3"
    init_db(db_path)
    with connect(db_path) as conn:
        dataset = SampleDataProvider().fetch()
        save_dataset(conn, dataset)
        summary = run_strategy(conn)
        assert summary.excluded_count >= 1
        assert table_count(conn, "market_score") == 1
        assert table_count(conn, "industry_score") > 0
        assert table_count(conn, "strategy_result") >= table_count(conn, "stock_basic")

        strategy_columns = {row["name"] for row in conn.execute("PRAGMA table_info(strategy_result)").fetchall()}
        for column in {
            "candidate_layer",
            "fundamental_status",
            "trend_template_type",
            "volume_quality",
            "close_quality",
            "risk_level",
            "trade_plan_type",
            "suggested_action",
            "buy_lower",
            "buy_upper",
            "suggested_buy_price",
            "stop_loss_price",
            "take_profit_1",
            "take_profit_2",
            "trailing_stop_rule",
            "suggested_position",
            "rejected_reason_detail",
            "risk_warning",
        }:
            assert column in strategy_columns

        industry_columns = {row["name"] for row in conn.execute("PRAGMA table_info(industry_score)").fetchall()}
        for column in {"stability_days", "rank_change", "score_change", "drift_flag", "base_score"}:
            assert column in industry_columns
        for column in {"leader_score", "hot_score", "candidate_stability_days", "confirmed_stability_days"}:
            assert column in industry_columns
        for column in {"leader_250_high_count", "leader_60_high_count", "leader_trend_middle_count"}:
            assert column in industry_columns

        plan_rows = conn.execute(
            """
            SELECT market_score, suggested_action, buy_lower, buy_upper, suggested_buy_price,
                   stop_loss_price, take_profit_1, take_profit_2, suggested_position
            FROM strategy_result
            WHERE status = 'included'
            """
        ).fetchall()
        for row in plan_rows:
            _assert_trade_plan_legality(dict(row))

        low_market_rows = conn.execute(
            """
            SELECT buy_lower, buy_upper, suggested_buy_price, take_profit_1,
                   take_profit_2, suggested_position, suggested_action
            FROM strategy_result
            WHERE status = 'included' AND market_score < 65
            """
        ).fetchall()
        for row in low_market_rows:
            assert row["suggested_action"] in {"仅观察", "等待回踩"}
            assert row["buy_lower"] is None
            assert row["buy_upper"] is None
            assert row["suggested_buy_price"] is None
            assert row["take_profit_1"] is None
            assert row["take_profit_2"] is None
            assert row["suggested_position"] == 0


def test_run_log_funnel_columns_after_migration(tmp_path: Path) -> None:
    db_path = tmp_path / "selector.sqlite3"
    init_db(db_path)
    with connect(db_path) as conn:
        run_log_cols = {row["name"] for row in conn.execute("PRAGMA table_info(run_log)").fetchall()}
        for col in ("total_stock_count", "after_basic_filter_count", "after_fundamental_filter_count",
                    "after_trend_filter_count", "after_keypoint_filter_count",
                    "after_mainline_filter_count", "after_market_filter_count"):
            assert col in run_log_cols, f"run_log missing column: {col}"


def test_sample_provider_includes_core_indices() -> None:
    dataset = SampleDataProvider().fetch()
    index_codes = set(dataset.index_daily["index_code"].astype(str).unique())
    for code in {"000300", "000905", "000852", "399303", "399006"}:
        assert code in index_codes


def test_funnel_counts_are_monotonic(tmp_path: Path) -> None:
    """Funnel counts must be monotonically decreasing: total >= basic >= fund >= trend >= kp >= candidates."""
    db_path = tmp_path / "selector.sqlite3"
    init_db(db_path)
    with connect(db_path) as conn:
        dataset = SampleDataProvider().fetch()
        save_dataset(conn, dataset)
        run_strategy(conn)
        log = conn.execute("SELECT * FROM run_log ORDER BY run_timestamp DESC LIMIT 1").fetchone()
        t = int(log["total_stock_count"])
        b = int(log["after_basic_filter_count"])
        f = int(log["after_fundamental_filter_count"])
        tr = int(log["after_trend_filter_count"])
        kp = int(log["after_keypoint_filter_count"])
        ml = int(log["after_mainline_filter_count"])
        mk = int(log["after_market_filter_count"])
        c = int(log["candidate_count"])
        assert t >= b >= f >= tr >= kp >= ml >= mk >= c, (
            f"Funnel not monotonic: {t} -> {b} -> {f} -> {tr} -> {kp} -> {ml} -> {mk} -> {c}"
        )
        assert t > 0, "total_stock_count should be > 0"
        assert c >= 0, "candidate_count should be >= 0"

        layers = {
            row["candidate_layer"]
            for row in conn.execute("SELECT DISTINCT candidate_layer FROM strategy_result").fetchall()
        }
        assert "剔除" in layers


def test_industry_leader_score_uses_stock_structure() -> None:
    dates = pd.date_range("2025-01-01", periods=270, freq="D").strftime("%Y-%m-%d")
    basics = pd.DataFrame(
        [
            {"code": "A", "name": "A", "industry": "半导体", "list_date": "20200101"},
            {"code": "B", "name": "B", "industry": "半导体", "list_date": "20200101"},
            {"code": "C", "name": "C", "industry": "半导体", "list_date": "20200101"},
        ]
    )
    rows = []
    for code in basics["code"]:
        for idx, trade_date in enumerate(dates):
            close = 10 + idx * 0.01
            rows.append(
                {
                    "code": code,
                    "trade_date": trade_date,
                    "open": close - 0.02,
                    "high": close + 0.05,
                    "low": close - 0.05,
                    "close": close,
                    "volume": 1_000_000,
                    "amount": 150_000_000,
                    "pct_chg": 1.0,
                    "turnover_rate": 2.0,
                }
            )
    stock_daily = pd.DataFrame(rows)
    latest = stock_daily[stock_daily["trade_date"] == dates[-1]]
    industry_daily = pd.DataFrame(
        {
            "industry": ["半导体"] * len(dates),
            "trade_date": dates,
            "close": [100 + i for i in range(len(dates))],
            "pct_chg": [1.0] * len(dates),
            "amount": [450_000_000] * len(dates),
            "up_count": [3] * len(dates),
            "down_count": [0] * len(dates),
            "limit_up_count": [0] * len(dates),
        }
    )
    # Force all three stocks to print fresh highs on the latest day.
    stock_daily.loc[latest.index, "close"] = 20
    stock_daily.loc[latest.index, "high"] = 20.2

    scored = score_industries(industry_daily, dates[-1], StrategyConfig(), stock_daily, basics)
    row = scored.iloc[0]
    assert row["leader_score"] == 15
    assert row["leader_250_high_count"] == 3
    assert row["leader_60_high_count"] == 3
    assert row["leader_trend_middle_count"] == 3
    assert row["base_score"] >= row["leader_score"]


def test_keypoint_price_and_leader_plan_formula() -> None:
    dates = pd.date_range("2025-01-01", periods=270, freq="D").strftime("%Y-%m-%d")
    close = [10 + i * 0.01 for i in range(269)] + [13.0]
    daily = pd.DataFrame(
        {
            "trade_date": dates,
            "open": [c - 0.05 for c in close],
            "high": [c + 0.10 for c in close[:-1]] + [13.05],
            "low": [c - 0.10 for c in close[:-1]] + [12.85],
            "close": close,
            "volume": [1_000_000] * 269 + [1_800_000],
            "amount": [120_000_000] * 270,
            "pct_chg": [1.0] * 270,
            "turnover_rate": [2.0] * 270,
        }
    )
    previous_high = float(daily.iloc[:-1]["high"].max())
    keypoint = _detect_keypoint(daily, "A", StrategyConfig())
    assert keypoint is not None
    assert keypoint["keypoint_price"] == previous_high

    plan = _build_trade_plan(
        latest=daily.iloc[-1],
        keypoint=keypoint,
        market={"total_score": 70, "risk_level": "可交易"},
        industry_state={"base_score": 85},
        trend_type="A",
        config=StrategyConfig(),
        stock_daily=daily,
    )
    assert plan["trade_plan_type"] == "龙头突破试错计划"
    assert plan["buy_lower"] == round(previous_high, 2)
    assert plan["buy_upper"] == round(previous_high * 1.02, 2)
    assert plan["take_profit_1"] == round(plan["suggested_buy_price"] * 1.10, 2)
    assert plan["take_profit_2"] == round(plan["suggested_buy_price"] * 1.20, 2)
    _assert_trade_plan_legality(plan)


def test_middle_pullback_requires_real_confirmation() -> None:
    dates = pd.date_range("2025-01-01", periods=270, freq="D").strftime("%Y-%m-%d")
    close = [10.0] * 266 + [10.30, 10.08, 10.12, 10.35]
    open_ = [9.98] * 266 + [10.05, 10.15, 10.10, 10.18]
    volume = [100_000] * 266 + [300_000, 100_000, 90_000, 420_000]
    daily = pd.DataFrame(
        {
            "trade_date": dates,
            "open": open_,
            "high": [c + 0.08 for c in close],
            "low": [9.95] * 266 + [10.05, 10.05, 10.06, 10.20],
            "close": close,
            "volume": volume,
            "amount": [120_000_000] * 270,
            "pct_chg": [0.5] * 270,
            "turnover_rate": [2.0] * 270,
        }
    )
    keypoint = {
        "keypoint_date": dates[-4],
        "breakout_date": dates[-4],
        "keypoint_price": 10.0,
        "keypoint_type": "120日平台突破",
        "breakout_close": 10.30,
        "breakout_day_low": 10.05,
        "breakout_ma10": 10.0,
    }
    plan = _build_trade_plan(
        latest=daily.iloc[-1],
        keypoint=keypoint,
        market={"total_score": 70, "risk_level": "可交易"},
        industry_state={"base_score": 75},
        trend_type="B",
        config=StrategyConfig(),
        stock_daily=daily,
    )
    assert plan["suggested_action"] == "建议计划买入"
    assert plan["pullback_volume_shrink"] == 1
    assert plan["confirm_volume_expand"] == 1
    assert plan["take_profit_1"] == round(plan["suggested_buy_price"] * 1.12, 2)
    assert plan["take_profit_2"] == round(plan["suggested_buy_price"] * 1.25, 2)
    _assert_trade_plan_legality(plan)


def test_middle_pullback_allows_first_day_confirmation() -> None:
    dates = pd.date_range("2025-01-01", periods=270, freq="D").strftime("%Y-%m-%d")
    close = [10.0] * 268 + [10.30, 10.16]
    open_ = [9.98] * 268 + [10.05, 10.05]
    volume = [100_000] * 268 + [300_000, 220_000]
    daily = pd.DataFrame(
        {
            "trade_date": dates,
            "open": open_,
            "high": [c + 0.08 for c in close],
            "low": [9.95] * 268 + [10.05, 10.12],
            "close": close,
            "volume": volume,
            "amount": [120_000_000] * 270,
            "pct_chg": [0.5] * 270,
            "turnover_rate": [2.0] * 270,
        }
    )
    keypoint = {
        "keypoint_date": dates[-2],
        "breakout_date": dates[-2],
        "keypoint_price": 10.0,
        "keypoint_type": "120日平台突破",
        "breakout_close": 10.30,
        "breakout_day_low": 10.05,
        "breakout_ma10": 10.0,
    }
    plan = _build_trade_plan(
        latest=daily.iloc[-1],
        keypoint=keypoint,
        market={"total_score": 70, "risk_level": "可交易"},
        industry_state={"base_score": 75},
        trend_type="B",
        config=StrategyConfig(),
        stock_daily=daily,
    )
    assert plan["suggested_action"] == "建议计划买入"
    assert plan["pullback_volume_shrink"] == 1
    assert plan["confirm_volume_expand"] == 1
    _assert_trade_plan_legality(plan)


def test_low_market_plan_never_outputs_buy_range() -> None:
    latest = pd.Series({"trade_date": "2025-01-02"})
    keypoint = {
        "keypoint_date": "2025-01-02",
        "breakout_date": "2025-01-02",
        "keypoint_price": 10.0,
        "keypoint_type": "250日新高",
        "breakout_close": 10.2,
        "breakout_day_low": 9.9,
        "breakout_ma10": 9.8,
    }
    plan = _build_trade_plan(
        latest=latest,
        keypoint=keypoint,
        market={"total_score": 60, "risk_level": "观察"},
        industry_state={"base_score": 90},
        trend_type="A",
        config=StrategyConfig(),
        stock_daily=None,
    )
    _assert_trade_plan_legality({"market_score": 60, **plan})


def _assert_trade_plan_legality(plan: dict) -> None:
    action = plan.get("suggested_action")
    market_score = plan.get("market_score")
    if action in {"建议试错买入", "建议计划买入"}:
        for field in (
            "buy_lower",
            "buy_upper",
            "suggested_buy_price",
            "stop_loss_price",
            "take_profit_1",
            "take_profit_2",
        ):
            assert plan.get(field) is not None, f"{field} should not be empty for {action}"
        buy_lower = float(plan["buy_lower"])
        buy_upper = float(plan["buy_upper"])
        suggested_buy = float(plan["suggested_buy_price"])
        stop_loss = float(plan["stop_loss_price"])
        take_profit_1 = float(plan["take_profit_1"])
        take_profit_2 = float(plan["take_profit_2"])
        assert buy_lower <= suggested_buy <= buy_upper
        assert stop_loss < suggested_buy
        assert take_profit_1 > suggested_buy
        assert take_profit_2 > take_profit_1
        assert float(plan["suggested_position"]) > 0
    if market_score is not None and float(market_score) < 65:
        assert action in {"仅观察", "等待回踩"}
        assert plan.get("buy_lower") is None
        assert plan.get("buy_upper") is None
        assert plan.get("suggested_buy_price") is None
        assert plan.get("take_profit_1") is None
        assert plan.get("take_profit_2") is None
        assert float(plan.get("suggested_position") or 0) == 0
