from __future__ import annotations

import argparse

from .data_provider import SampleDataProvider, TushareDataProvider, save_dataset, save_dataset_incremental
from .db import DEFAULT_DB_PATH, connect, init_db, table_count
from .strategy import run_strategy


def main() -> None:
    parser = argparse.ArgumentParser(prog="a-stock-selector")
    parser.add_argument("--db", default=str(DEFAULT_DB_PATH), help="SQLite database path")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init", help="Create database and load sample data")
    sub.add_parser("fetch", help="Fetch full-market data from Tushare")
    run_parser = sub.add_parser("run", help="Run selector strategy")
    run_parser.add_argument("--refresh", action="store_true", help="Refresh data before running")
    args = parser.parse_args()

    init_db(args.db)
    with connect(args.db) as conn:
        if args.command == "init":
            dataset = SampleDataProvider().fetch()
            save_dataset(conn, dataset)
            print(f"initialized {args.db} with {table_count(conn, 'stock_basic')} stocks")
            return
        if args.command == "fetch":
            skip_dates = _reusable_trade_dates(conn) if _current_source(conn) == "tushare" else set()
            dataset = TushareDataProvider(max_stocks=0, skip_trade_dates=skip_dates).fetch()
            if skip_dates:
                save_dataset_incremental(conn, dataset)
            else:
                save_dataset(conn, dataset)
            print(f"fetched data_source={dataset.source_name}, stocks={table_count(conn, 'stock_basic')}")
            return
        if args.command == "run":
            if args.refresh or table_count(conn, "stock_daily") == 0:
                skip_dates = _reusable_trade_dates(conn) if _current_source(conn) == "tushare" else set()
                dataset = TushareDataProvider(max_stocks=0, skip_trade_dates=skip_dates).fetch()
                if skip_dates:
                    save_dataset_incremental(conn, dataset)
                else:
                    save_dataset(conn, dataset)
            row = conn.execute("SELECT data_source FROM data_snapshot WHERE id = 1").fetchone()
            if not row or row["data_source"] != "tushare":
                raise SystemExit("No Tushare dataset loaded. Run `a-stock-selector fetch` first.")
            summary = run_strategy(conn)
            print(
                "batch_id={batch_id} trade_date={trade_date} candidates={candidate_count} "
                "excluded={excluded_count}".format(**summary.__dict__)
            )

def _current_source(conn) -> str:
    row = conn.execute("SELECT data_source FROM data_snapshot WHERE id = 1").fetchone()
    return str(row["data_source"]) if row else ""


def _reusable_trade_dates(conn, keep_recent: int = 5) -> set[str]:
    rows = conn.execute("SELECT DISTINCT trade_date FROM stock_daily ORDER BY trade_date").fetchall()
    dates = [str(row["trade_date"]) for row in rows]
    if len(dates) <= keep_recent:
        return set()
    return set(dates[:-keep_recent])


if __name__ == "__main__":
    main()
